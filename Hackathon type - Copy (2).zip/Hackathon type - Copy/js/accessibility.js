// Accessibility settings
const accessibilitySettings = {
    highContrast: false,
    colorblind: false,
    language: 'en',
    soundEnabled: true
};

// Translations for different languages
const translations = {
    en: {
        accessibility: "Accessibility",
        welcome: "Welcome back!",
        display_settings: "Display Settings",
        high_contrast: "High Contrast Mode",
        high_contrast_desc: "Increases contrast for better readability",
        colorblind_mode: "Colorblind Mode",
        colorblind_desc: "Adjusts colors for colorblind users",
        language_settings: "Language Settings",
        select_language: "Select Language",
        language_desc: "Choose your preferred language",
        sound_settings: "Sound Settings",
        sound_effects: "Sound Effects",
        sound_effects_desc: "Enable or disable sound effects",
        dashboard: "Dashboard",
        tasks: "Tasks",
        schedule: "Schedule",
        stress_tracker: "Stress Tracker",
        analytics: "Analytics",
        ai_planner: "AI Planner",
        stress_level: "Stress Level",
        add_task: "Add Task",
        task_name: "Task Name",
        due_date: "Due Date",
        priority: "Priority",
        description: "Description",
        cancel: "Cancel",
        save: "Save",
        completed_tasks: "Completed Tasks",
        upcoming_tasks: "Upcoming Tasks",
        no_tasks: "No tasks available",
        today_schedule: "Today's Schedule",
        stress_insights: "Stress Insights"
    },
    es: {
        accessibility: "Accesibilidad",
        welcome: "¡Bienvenido de nuevo!",
        display_settings: "Configuración de Pantalla",
        high_contrast: "Modo de Alto Contraste",
        high_contrast_desc: "Aumenta el contraste para mejor legibilidad",
        colorblind_mode: "Modo Daltónico",
        colorblind_desc: "Ajusta los colores para usuarios daltónicos",
        language_settings: "Configuración de Idioma",
        select_language: "Seleccionar Idioma",
        language_desc: "Elige tu idioma preferido",
        sound_settings: "Configuración de Sonido",
        sound_effects: "Efectos de Sonido",
        sound_effects_desc: "Activar o desactivar efectos de sonido",
        dashboard: "Panel",
        tasks: "Tareas",
        schedule: "Horario",
        stress_tracker: "Seguimiento de Estrés",
        analytics: "Analítica",
        ai_planner: "Planificador IA",
        stress_level: "Nivel de Estrés",
        add_task: "Añadir Tarea",
        task_name: "Nombre de la Tarea",
        due_date: "Fecha de Vencimiento",
        priority: "Prioridad",
        description: "Descripción",
        cancel: "Cancelar",
        save: "Guardar",
        completed_tasks: "Tareas Completadas",
        upcoming_tasks: "Próximas Tareas",
        no_tasks: "No hay tareas disponibles",
        today_schedule: "Horario de Hoy",
        stress_insights: "Información de Estrés"
    },
    de: {
        accessibility: "Barrierefreiheit",
        welcome: "Willkommen zurück!",
        display_settings: "Anzeigeeinstellungen",
        high_contrast: "Hochkontrastmodus",
        high_contrast_desc: "Erhöht den Kontrast für bessere Lesbarkeit",
        colorblind_mode: "Farbenblindmodus",
        colorblind_desc: "Passt Farben für farbenblinde Benutzer an",
        language_settings: "Spracheinstellungen",
        select_language: "Sprache auswählen",
        language_desc: "Wähle deine bevorzugte Sprache",
        sound_settings: "Toneinstellungen",
        sound_effects: "Soundeffekte",
        sound_effects_desc: "Soundeffekte aktivieren oder deaktivieren",
        dashboard: "Dashboard",
        tasks: "Aufgaben",
        schedule: "Zeitplan",
        stress_tracker: "Stressverfolgung",
        analytics: "Analytik",
        ai_planner: "KI-Planer",
        stress_level: "Stresslevel",
        add_task: "Aufgabe hinzufügen",
        task_name: "Aufgabenname",
        due_date: "Fälligkeitsdatum",
        priority: "Priorität",
        description: "Beschreibung",
        cancel: "Abbrechen",
        save: "Speichern",
        completed_tasks: "Erledigte Aufgaben",
        upcoming_tasks: "Anstehende Aufgaben",
        no_tasks: "Keine Aufgaben verfügbar",
        today_schedule: "Heutiger Zeitplan",
        stress_insights: "Stresseinblicke"
    }
};

// Load settings from localStorage
function loadAccessibilitySettings() {
    const savedSettings = localStorage.getItem('timetravel_accessibility');
    if (savedSettings) {
        Object.assign(accessibilitySettings, JSON.parse(savedSettings));
        
        // Apply saved settings
        document.getElementById('highContrastToggle').checked = accessibilitySettings.highContrast;
        document.getElementById('colorblindToggle').checked = accessibilitySettings.colorblind;
        document.getElementById('languageSelect').value = accessibilitySettings.language;
        document.getElementById('soundToggle').checked = accessibilitySettings.soundEnabled;
        
        applyAccessibilitySettings();
    }
}

// Save settings to localStorage
function saveAccessibilitySettings() {
    localStorage.setItem('timetravel_accessibility', JSON.stringify(accessibilitySettings));
}

// Apply accessibility settings to the page
function applyAccessibilitySettings() {
    // Apply high contrast mode
    document.documentElement.setAttribute('data-high-contrast', accessibilitySettings.highContrast);
    
    // Apply colorblind mode
    document.documentElement.setAttribute('data-colorblind', accessibilitySettings.colorblind);
    
    // Apply language
    applyLanguage(accessibilitySettings.language);
    
    // Apply sound settings
    if (window.hoverSound && window.clickSound) {
        window.hoverSound.muted = !accessibilitySettings.soundEnabled;
        window.clickSound.muted = !accessibilitySettings.soundEnabled;
    }
}

// Apply language translations
function applyLanguage(lang) {
    if (!translations[lang]) return;
    
    const elements = document.querySelectorAll('.i18n');
    elements.forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (key && translations[lang][key]) {
            el.textContent = translations[lang][key];
        }
    });
    
    // Update navigation text
    updateNavigationText(lang);
}

// Update navigation text with translations
function updateNavigationText(lang) {
    if (!translations[lang]) return;
    
    const navItems = {
        'index.html': 'dashboard',
        'tasks.html': 'tasks',
        'schedule.html': 'schedule',
        'stress.html': 'stress_tracker',
        'analytics.html': 'analytics',
        'planner.html': 'ai_planner',
        'accessibility.html': 'accessibility'
    };
    
    document.querySelectorAll('.nav-btn').forEach(btn => {
        const page = btn.getAttribute('data-page');
        const textEl = btn.querySelector('.nav-text');
        if (textEl && page && navItems[page] && translations[lang][navItems[page]]) {
            textEl.textContent = translations[lang][navItems[page]];
        }
    });
    
    // Update stress level text
    const stressLevelEl = document.querySelector('.stress-meter h3 .nav-text');
    if (stressLevelEl && translations[lang]['stress_level']) {
        stressLevelEl.textContent = translations[lang]['stress_level'];
    }
}

// Initialize accessibility settings
document.addEventListener('DOMContentLoaded', function() {
    // Load saved settings
    loadAccessibilitySettings();
    
    // Set up event listeners for accessibility toggles
    const highContrastToggle = document.getElementById('highContrastToggle');
    if (highContrastToggle) {
        highContrastToggle.addEventListener('change', function() {
            accessibilitySettings.highContrast = this.checked;
            saveAccessibilitySettings();
            applyAccessibilitySettings();
        });
    }
    
    const colorblindToggle = document.getElementById('colorblindToggle');
    if (colorblindToggle) {
        colorblindToggle.addEventListener('change', function() {
            accessibilitySettings.colorblind = this.checked;
            saveAccessibilitySettings();
            applyAccessibilitySettings();
        });
    }
    
    const languageSelect = document.getElementById('languageSelect');
    if (languageSelect) {
        languageSelect.addEventListener('change', function() {
            accessibilitySettings.language = this.value;
            saveAccessibilitySettings();
            applyAccessibilitySettings();
        });
    }
    
    const soundToggle = document.getElementById('soundToggle');
    if (soundToggle) {
        soundToggle.addEventListener('change', function() {
            accessibilitySettings.soundEnabled = this.checked;
            saveAccessibilitySettings();
            applyAccessibilitySettings();
        });
    }
});

// Apply settings on page load
applyAccessibilitySettings();
