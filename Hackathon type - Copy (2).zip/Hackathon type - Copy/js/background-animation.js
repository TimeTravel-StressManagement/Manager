// Background Animation

document.addEventListener('DOMContentLoaded', function() {
    // Replace the old particles animation with the new one
    const oldParticles = document.querySelector('.particles-container');
    if (oldParticles) {
        oldParticles.remove();
    }

    // Create new animated background
    const animatedBackground = document.createElement('div');
    animatedBackground.className = 'animated-background';

    // Add waves
    for (let i = 0; i < 4; i++) {
        const wave = document.createElement('div');
        wave.className = 'wave';
        animatedBackground.appendChild(wave);
    }

    // Add glow orbs
    const orbColors = [
        'rgba(110, 86, 207, 0.3)',  // primary color
        'rgba(167, 139, 250, 0.2)',  // primary glow
        'rgba(255, 125, 84, 0.2)',   // secondary color
        'rgba(0, 212, 255, 0.2)'     // tertiary color
    ];

    for (let i = 0; i < 5; i++) {
        const orb = document.createElement('div');
        orb.className = 'orb';
        orb.style.width = `${Math.random() * 300 + 200}px`;
        orb.style.height = orb.style.width;
        orb.style.left = `${Math.random() * 100}%`;
        orb.style.top = `${Math.random() * 100}%`;
        orb.style.background = orbColors[i % orbColors.length];
        orb.style.animationDelay = `${i * 2}s`;
        orb.style.animationDuration = `${15 + Math.random() * 10}s`;
        animatedBackground.appendChild(orb);
    }

    // Add constellation
    const constellation = document.createElement('div');
    constellation.className = 'constellation';

    // Add stars to constellation
    for (let i = 0; i < 100; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        star.style.width = `${Math.random() * 2 + 1}px`;
        star.style.height = star.style.width;
        star.style.left = `${Math.random() * 100}%`;
        star.style.top = `${Math.random() * 100}%`;
        star.style.opacity = Math.random() * 0.5 + 0.1;
        star.style.animationDelay = `${Math.random() * 5}s`;
        constellation.appendChild(star);
    }

    animatedBackground.appendChild(constellation);

    // Add to body before the app container
    const appContainer = document.querySelector('.app-container');
    if (appContainer) {
        document.body.insertBefore(animatedBackground, appContainer);
    } else {
        document.body.appendChild(animatedBackground);
    }

    // Remove interactive grid if it exists
    const interactiveGrid = document.querySelector('.interactive-grid');
    if (interactiveGrid) {
        interactiveGrid.remove();
    }
});
