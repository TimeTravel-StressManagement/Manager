// Sound effects for the application
const hoverSound = new Audio('hover sound.mp3');
const clickSound = new Audio('click confirm sound.mp3');

// Preload sounds
function preloadSounds() {
    hoverSound.load();
    clickSound.load();
}

// Initialize sound effects for all buttons
function initSoundEffects() {
    // Preload the sounds
    preloadSounds();
    
    // Get all buttons and elements with button classes
    const buttons = document.querySelectorAll('button, .button, .btn, .btn-primary, .btn-secondary, .nav-btn, .task-checkbox input');
    
    // Add event listeners to each button
    buttons.forEach(button => {
        // Play hover sound on mouseenter
        button.addEventListener('mouseenter', () => {
            hoverSound.currentTime = 0; // Reset sound to beginning
            hoverSound.play().catch(e => console.log('Error playing hover sound:', e));
        });
        
        // Play click sound on click
        button.addEventListener('click', () => {
            clickSound.currentTime = 0; // Reset sound to beginning
            clickSound.play().catch(e => console.log('Error playing click sound:', e));
        });
    });
    
    // Add sound effects to dynamically added elements using MutationObserver
    const addSoundToElement = (element) => {
        if (element.tagName === 'BUTTON' || 
            element.classList.contains('button') || 
            element.classList.contains('btn') ||
            element.classList.contains('btn-primary') ||
            element.classList.contains('btn-secondary') ||
            element.classList.contains('nav-btn')) {
            
            // add hover sound
            element.addEventListener('mouseenter', () => {
                hoverSound.currentTime = 0;
                hoverSound.play().catch(e => console.log('Error playing hover sound:', e));
            });
            
            // Add click sound
            element.addEventListener('click', () => {
                clickSound.currentTime = 0;
                clickSound.play().catch(e => console.log('Error playing click sound:', e));
            });
        }
    };
    
    // Create a MutationObserver to watch for new elements
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach((node) => {
                    // Check if the node is an Element
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        // Check the element itself
                        addSoundToElement(node);
                        
                        // Check all child elements
                        const buttons = node.querySelectorAll('button, .button, .btn, .btn-primary, .btn-secondary, .nav-btn');
                        buttons.forEach(addSoundToElement);
                    }
                });
            }
        });
    });
    
    // Start observing the document with the configured parameters
    observer.observe(document.body, { childList: true, subtree: true });
}

// Export functions
window.initSoundEffects = initSoundEffects;
