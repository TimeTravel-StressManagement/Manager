// local storage keys
const STORAGE_KEYS = {
    TASKS: 'timetravel_tasks',
    STRESS_LEVELS: 'timetravel_stress_levels',
    USER_PROFILE: 'timetravel_user_profile'
};

// app state
let state = {
    tasks: [],
    stressLevels: [],
    userProfile: null
};

// LeStartup
document.addEventListener('DOMContentLoaded', function() {
    loadDataFromStorage();
    setupEventListeners();
    
    // figure out which page we're on
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    // load stuff specific to this page
    initializePage(currentPage);
    
    // setup common stuff like the stress meter & reset button
    initializeStressMeter();
    addResetButton();

    // Update time and date display
    updateTimeAndDate();
    setInterval(updateTimeAndDate, 1000);

    const gridContainer = document.querySelector('.interactive-grid');
    const numSquares = Math.floor(window.innerWidth / 20) * Math.floor(window.innerHeight / 20);

    for (let i = 0; i < numSquares; i++) {
        const square = document.createElement('div');
        gridContainer.appendChild(square);
    }
});

// init page based on filename
function initializePage(page) {
    switch(page) {
        case 'index.html':
            initializeDashboard();
            break;
        case 'tasks.html':
            initializeTasks();
            break;
        case 'schedule.html':
            initializeCalendar();
            break;
        case 'stress.html':
            initializeStressTracker();
            break;
        case 'analytics.html':
            initializeAnalytics();
            break;
    }
}

// grab saved data from local storage
function loadDataFromStorage() {
    state.tasks = JSON.parse(localStorage.getItem(STORAGE_KEYS.TASKS) || '[]');
    state.stressLevels = JSON.parse(localStorage.getItem(STORAGE_KEYS.STRESS_LEVELS) || '[]');
    state.userProfile = JSON.parse(localStorage.getItem(STORAGE_KEYS.USER_PROFILE) || 'null');
}

// save current state to local storage
function saveDataToStorage() {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(state.tasks));
    localStorage.setItem(STORAGE_KEYS.STRESS_LEVELS, JSON.stringify(state.stressLevels));
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(state.userProfile));
}

// wire up event listeners
function setupEventListeners() {
    // nav buttons
    document.querySelectorAll('.nav-btn').forEach(button => {
        button.addEventListener('click', function() {
            const page = this.dataset.page;
            window.location.href = page;
        });
    });

    // stress slider and confirm button
    const stressSlider = document.getElementById('stressLevel');
    const confirmStressBtn = document.getElementById('confirmStress');
    if (stressSlider) {
        stressSlider.addEventListener('input', (e) => {
            const value = parseInt(e.target.value);
            document.querySelector('.stress-value').textContent = `${value}/10`;
        });
        
        // set initial val from storage or default to 5
        const currentStress = state.stressLevels.length > 0 
            ? state.stressLevels[state.stressLevels.length - 1].value 
            : 5;
        stressSlider.value = currentStress;
        document.querySelector('.stress-value').textContent = `${currentStress}/10`;
    }
    
    if (confirmStressBtn) {
        confirmStressBtn.addEventListener('click', () => {
            const value = parseInt(document.getElementById('stressLevel').value);
            
            // save the new stress level with timestamp
            state.stressLevels.push({
                value: value,
                timestamp: new Date().toISOString()
            });
            
            saveDataToStorage();
            
            // update charts if they're on the page
            if (window.stressChart) {
                updateStressChart();
            }
            if (window.stressHistoryChart) {
                updateStressHistoryChart();
            }
            if (window.stressWorkloadChart) {
                updateStressWorkloadChart();
            }
            
            updateStressInsights();
            updateRecommendations();
            updateUI();
            
            // play sound effect
            if (window.playSliderSound) {
                window.playSliderSound();
            }
            
            // Show confirmation
            showNotification('Stress level recorded', 'success');
        });
    }
    
    // Initialize sound effects for buttons
    if (window.initSoundEffects) {
        window.initSoundEffects();
    }
}

// handle stress slider changes
function handleStressLevelChange(e) {
    const value = parseInt(e.target.value);
    document.querySelector('.stress-value').textContent = `${value}/10`;
    
    // save the new stress level
    state.stressLevels.push({
        value: value,
        timestamp: new Date().toISOString()
    });
    
    saveDataToStorage();
    
    // update charts if they're on the page
    if (window.stressChart) {
        updateStressChart();
    }
    if (window.stressHistoryChart) {
        updateStressHistoryChart();
    }
    
    // update insights if on stress page
    if (document.getElementById('stressInsights')) {
        updateStressInsights();
    }
    
    // update recommendations if on dashboard
    if (document.getElementById('recommendationsList')) {
        updateRecommendations();
    }
}

// set initial stress meter value
function initializeStressMeter() {
    const stressSlider = document.getElementById('stressLevel');
    const stressValue = document.querySelector('.stress-value');
    
    if (stressSlider && stressValue) {
        // get last saved stress or default to 5
        const currentStress = state.stressLevels.length > 0 
            ? state.stressLevels[state.stressLevels.length - 1].value 
            : 5;
        stressSlider.value = currentStress;
        stressValue.textContent = `${currentStress}/10`;
    }
}

// set up the stress chart on the dashboard
function initializeStressChart() {
    const ctx = document.getElementById('stressChart');
    if (!ctx) return;

    window.stressChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Stress Level',
                data: [],
                borderColor: '#007AFF',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    min: 1,
                    max: 10,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
    updateStressChart();
}

// update the dashboard stress chart data
function updateStressChart() {
    if (!window.stressChart) return;

    const recentStressLevels = state.stressLevels.slice(-7);
    window.stressChart.data.labels = recentStressLevels.map(level => {
        const date = new Date(level.timestamp);
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + '\n' + 
               date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    });
    window.stressChart.data.datasets[0].data = recentStressLevels.map(level => level.value);
    window.stressChart.update();
}

// set up the history chart on the stress tracker page
function initializeStressTracker() {
    const ctx = document.getElementById('stressHistoryChart');
    if (!ctx) return;

    window.stressHistoryChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Stress Level',
                data: [],
                borderColor: '#FF6B6B',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10
                }
            }
        }
    });
    
    updateStressHistoryChart();
    updateStressInsights();
}

// update the stress history chart data
function updateStressHistoryChart() {
    if (!window.stressHistoryChart) return;

    const recentStressLevels = state.stressLevels.slice(-7);
    window.stressHistoryChart.data.labels = recentStressLevels.map(level => 
        new Date(level.timestamp).toLocaleDateString()
    );
    window.stressHistoryChart.data.datasets[0].data = recentStressLevels.map(level => level.value);
    window.stressHistoryChart.update();
}

// set up the dashboard
function initializeDashboard() {
    // set up quick add form
    const quickAddForm = document.getElementById('quickAddForm');
    if (quickAddForm) {
        quickAddForm.addEventListener('submit', handleQuickAddTask);
        console.log('Quick add form event listener added'); // debug log
    } else {
        console.log('Quick add form not found'); // debug log
    }
    
    // update today's tasks
    updateTodayTasks();
    
    // set up stress chart
    initializeStressChart();
    
    // update recommendations
    updateRecommendations();
}

// set up the tasks page
function initializeTasks() {
    console.log('Initializing Tasks Page'); // debug log
    
    // load data first
    loadDataFromStorage();
    console.log('Loaded state:', state); // debug log
    
    // wire up the add task button
    const addTaskBtn = document.querySelector('.add-task-btn');
    if (addTaskBtn) {
        addTaskBtn.addEventListener('click', showAddTaskModal);
    }
    
    // show the tasks
    updateTaskLists();
}

// update the 'today's tasks' section (mainly for dashboard)
function updateTodayTasks() {
    const todayTasks = document.getElementById('todayTasks');
    if (!todayTasks) return;
    
    const today = new Date().toDateString();
    const tasks = state.tasks.filter(task => 
        new Date(task.deadline).toDateString() === today
    );
    
    todayTasks.innerHTML = tasks.length ? 
        tasks.map(task => createTaskHTML(task)).join('') :
        '<p>No tasks for today!</p>';
    
    // Update task counters in the dashboard
    const completedCount = document.getElementById('completedCount');
    const pendingCount = document.getElementById('pendingCount');
    
    if (completedCount && pendingCount) {
        const completed = tasks.filter(task => task.completed).length;
        const pending = tasks.length - completed;
        
        completedCount.textContent = completed;
        pendingCount.textContent = pending;
    }
}

// creates the html for a single task item
function createTaskHTML(task) {
    const deadline = new Date(task.deadline);
    const isOverdue = !task.completed && deadline < new Date();
    
    return `
        <div class="task-item ${task.completed ? 'completed' : ''} ${isOverdue ? 'overdue' : ''}" data-id="${task.id}">
            <div class="task-checkbox">
                <input type="checkbox" ${task.completed ? 'checked' : ''} 
                       onclick="toggleTaskComplete(${task.id})">
            </div>
            <div class="task-content">
                <div class="task-header">
                    <h3 class="task-name">${task.name || 'Untitled Task'}</h3>
                    <span class="priority ${(task.priority || 'medium').toLowerCase()}">${task.priority || 'Medium'}</span>
                </div>
                ${task.description ? `<p class="task-description">${task.description}</p>` : ''}
                <div class="task-meta">
                    <span class="deadline ${isOverdue ? 'overdue' : ''}">
                        Due: ${deadline.toLocaleString()}
                    </span>
                </div>
            </div>
            <div class="task-actions">
                <button class="edit-task-btn" onclick="showEditTaskModal(${task.id})">
                    <i class="bi bi-pencil"></i>
                </button>
            </div>
        </div>
    `;
}

// handle clicking the task checkbox
function toggleTaskComplete(taskId) {
    console.log('Toggling task:', taskId);
    
    const task = state.tasks.find(t => t.id === taskId);
    if (task) {
        const wasIncomplete = !task.completed;
        task.completed = !task.completed;
        saveDataToStorage();
        updateTaskLists();
        
        // recalc stress when task is completed/uncompleted
        updateStressFromTasks();
        
        // Trigger confetti only when task is being completed (not when uncompleted)
        if (wasIncomplete && task.completed) {
            triggerConfetti();
        }
        
        showNotification(
            task.completed ? 'Task marked as complete!' : 'Task marked as incomplete',
            'success'
        );
    }
}

// shows the modal to edit a task
function showEditTaskModal(taskId) {
    const task = state.tasks.find(t => t.id === taskId);
    if (!task) return;
    
    // Format the deadline for the datetime-local input
    const deadline = new Date(task.deadline);
    const formattedDate = deadline.toISOString().slice(0, 16); // Format: YYYY-MM-DDThh:mm
    
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-card">
            <h2>Edit Task</h2>
            <form id="editTaskForm">
                <div class="form-group">
                    <label for="editTaskName">Task Name</label>
                    <input type="text" id="editTaskName" value="${task.name || ''}" required>
                </div>
                <div class="form-group">
                    <label for="editTaskDeadline">Due Date & Time</label>
                    <input type="datetime-local" id="editTaskDeadline" value="${formattedDate}" required>
                </div>
                <div class="form-group">
                    <label for="editTaskPriority">Priority</label>
                    <select id="editTaskPriority">
                        <option value="low" ${task.priority === 'low' ? 'selected' : ''}>Low Priority</option>
                        <option value="medium" ${task.priority === 'medium' || !task.priority ? 'selected' : ''}>Medium Priority</option>
                        <option value="high" ${task.priority === 'high' ? 'selected' : ''}>High Priority</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="editTaskDescription">Description (Optional)</label>
                    <textarea id="editTaskDescription">${task.description || ''}</textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-secondary button" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-primary button">Save Changes</button>
                </div>
                <input type="hidden" id="editTaskId" value="${taskId}">
            </form>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add event listener to the form
    const editTaskForm = document.getElementById('editTaskForm');
    if (editTaskForm) {
        editTaskForm.addEventListener('submit', handleEditTask);
    }
}

// Handle the edit task form submission
function handleEditTask(e) {
    e.preventDefault();
    
    const taskId = parseInt(document.getElementById('editTaskId').value);
    const task = state.tasks.find(t => t.id === taskId);
    
    if (task) {
        // Update task properties
        task.name = document.getElementById('editTaskName').value;
        task.deadline = new Date(document.getElementById('editTaskDeadline').value).toISOString();
        task.priority = document.getElementById('editTaskPriority').value;
        task.description = document.getElementById('editTaskDescription').value;
        
        // Save changes
        saveDataToStorage();
        updateTaskLists();
        
        // Close modal and show notification
        closeModal();
        showNotification('Task updated successfully!', 'success');
    }
}

// shows the modal to add a new task
function showAddTaskModal() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-card">
            <h2>Add New Task</h2>
            <form id="addTaskForm">
                <div class="form-group">
                    <label for="taskName">Task Name</label>
                    <input type="text" id="taskName" placeholder="Enter task name" required>
                </div>
                <div class="form-group">
                    <label for="taskDescription">Description (optional)</label>
                    <textarea id="taskDescription" placeholder="Enter task description"></textarea>
                </div>
                <div class="form-group">
                    <label for="taskDeadline">Deadline</label>
                    <input type="datetime-local" id="taskDeadline" required>
                </div>
                <div class="form-group">
                    <label for="taskPriority">Priority</label>
                    <select id="taskPriority" required>
                        <option value="Low">Low Priority</option>
                        <option value="Medium">Medium Priority</option>
                        <option value="High">High Priority</option>
                    </select>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-primary">Add Task</button>
                </div>
            </form>
        </div>
    `;
    
    document.body.appendChild(modal);
    const form = document.getElementById('addTaskForm');
    form.addEventListener('submit', handleAddTask);
    
    // make sure deadline can't be in the past
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('taskDeadline').min = now.toISOString().slice(0, 16);
}

// closes the currently open modal
function closeModal() {
    const modal = document.querySelector('.modal-overlay');
    if (modal) modal.remove();
}

// handle submitting the add task form
function handleAddTask(e) {
    e.preventDefault();
    const form = e.target;
    const task = {
        id: Date.now(),
        name: form.querySelector('#taskName').value,
        description: form.querySelector('#taskDescription').value,
        deadline: form.querySelector('#taskDeadline').value,
        priority: form.querySelector('#taskPriority').value,
        completed: false,
        createdAt: new Date().toISOString()
    };
    
    // add task to state
    if (!state.tasks) state.tasks = [];
    state.tasks.push(task);
    
    // save, close modal, update ui
    saveDataToStorage();
    closeModal();
    updateTaskLists();
    
    // recalc stress based on new task
    updateStressFromTasks();
    
    // show confirmation
    showNotification('Task added successfully!', 'success');
}

// handle the quick add form on the dashboard
function handleQuickAddTask(e) {
    e.preventDefault();
    const form = e.target;
    const taskName = form.querySelector('#taskName').value.trim();
    const taskDeadline = form.querySelector('#taskDeadline').value;
    const taskPriority = form.querySelector('#taskPriority').value;
    
    if (!taskName) {
        showNotification('Please enter a task name', 'error');
        return;
    }
    
    const task = {
        id: Date.now(),
        name: taskName,
        description: '',
        deadline: taskDeadline,
        priority: taskPriority.charAt(0).toUpperCase() + taskPriority.slice(1), // Capitalize first letter
        completed: false,
        createdAt: new Date().toISOString()
    };
    
    // add task to state
    if (!state.tasks) state.tasks = [];
    state.tasks.push(task);
    
    // save and update ui
    saveDataToStorage();
    form.reset();
    updateTaskLists();
    updateTodayTasks();
    
    // recalc stress based on new task
    updateStressFromTasks();
    
    // show confirmation
    showNotification('Task added successfully!', 'success');
}

// add the reset button to the page
function addResetButton() {
    const resetButton = document.createElement('button');
    resetButton.className = 'reset-button';
    resetButton.textContent = 'Reset App';
    resetButton.onclick = function() {
        if (confirm('Are you sure you want to reset all data? This cannot be undone.')) {
            localStorage.clear();
            window.location.reload();
        }
    };
    document.body.appendChild(resetButton);
}

// updates the old weekly schedule view (not used anymore?)
function updateWeeklySchedule() {
    const weeklySchedule = document.getElementById('weeklySchedule');
    if (!weeklySchedule) return;

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const today = new Date().getDay();
    
    weeklySchedule.innerHTML = days.map((day, index) => {
        const isToday = index === today;
        const dayTasks = state.tasks.filter(task => new Date(task.deadline).getDay() === index);
        
        return `
            <div class="schedule-day ${isToday ? 'today' : ''}">
                <h3>${day}</h3>
                <div class="day-task-count">${dayTasks.length} tasks</div>
            </div>
        `;
    }).join('');
}

// update the time blocks view (usually for today)
function updateTimeBlocks() {
    const timeBlocks = document.getElementById('timeBlocks');
    if (!timeBlocks) return;

    const now = new Date();
    const todayTasks = state.tasks.filter(task => {
        const taskDate = new Date(task.deadline);
        return taskDate.toDateString() === now.toDateString();
    }).sort((a, b) => new Date(a.deadline) - new Date(b.deadline));

    timeBlocks.innerHTML = todayTasks.length ? todayTasks.map(task => `
        <div class="time-block" data-priority="${task.priority}">
            <div class="time-block-time">${new Date(task.deadline).toLocaleTimeString()}</div>
            <div class="time-block-name">${task.name}</div>
            <div class="time-block-priority ${task.priority}">${task.priority}</div>
        </div>
    `).join('') : '<p>No tasks scheduled for today</p>';
}

// update the stress insights section ts pmo
function updateStressInsights() {
    const stressInsights = document.getElementById('stressInsights');
    if (!stressInsights) return;

    const recentStress = state.stressLevels.slice(-7);
    const averageStress = recentStress.reduce((acc, curr) => acc + curr.value, 0) / recentStress.length;
    const stressChange = recentStress.length > 1 ? 
        recentStress[recentStress.length - 1].value - recentStress[0].value : 0;

    let insights = `
        <div class="insights-container">
            <div class="insight-item">
                <h3>Weekly Average</h3>
                <div class="insight-value">${averageStress.toFixed(1)}</div>
                <div class="insight-trend ${stressChange > 0 ? 'up' : 'down'}">
                    ${Math.abs(stressChange).toFixed(1)} points ${stressChange > 0 ? '↑' : '↓'}
                </div>
            </div>
            <div class="insight-recommendations">
                <h3>Recommendations</h3>
                ${generateStressRecommendations(averageStress)}
            </div>
        </div>
    `;

    stressInsights.innerHTML = insights;
}

// generate advice based on avg stress
function generateStressRecommendations(averageStress) {
    let recommendations = [];

    if (averageStress > 7) {
        recommendations.push('Consider taking regular breaks and practicing relaxation techniques');
        recommendations.push('Break down large tasks into smaller, manageable chunks');
    } else if (averageStress > 5) {
        recommendations.push('Maintain a balanced schedule between work and rest');
        recommendations.push('Review your task priorities and deadlines');
    } else {
        recommendations.push('Great job managing stress! Keep up your current routine');
        recommendations.push('Plan ahead to maintain this balanced state');
    }

    return recommendations.map(rec => `<div class="recommendation">${rec}</div>`).join('');
}

// update the upcoming/completed task lists
function updateTaskLists() {
    const now = new Date();
    
    // get tasks from state
    const tasks = state.tasks || [];
    console.log('Current tasks:', tasks); // debug log
    
    // filter em
    const upcomingTasks = tasks.filter(task => !task.completed);
    const completedTasks = tasks.filter(task => task.completed);
    
    console.log('Upcoming tasks:', upcomingTasks); // debug log
    console.log('Completed tasks:', completedTasks); // debug log

    // update upcoming list html
    const upcomingList = document.getElementById('upcomingTasks');
    if (upcomingList) {
        upcomingList.innerHTML = upcomingTasks.length ? 
            upcomingTasks.map(task => createTaskHTML(task)).join('') :
            '<p class="empty-state">No upcoming tasks</p>';
    }

    // update completed list html
    const completedList = document.getElementById('completedTasks');
    if (completedList) {
        completedList.innerHTML = completedTasks.length ?
            completedTasks.map(task => createTaskHTML(task)).join('') :
            '<p class="empty-state">No completed tasks</p>';
    }
}

// update the recommendations section on dashboard
function updateRecommendations() {
    const recommendationsList = document.getElementById('recommendationsList');
    if (recommendationsList) {
        recommendationsList.innerHTML = generateRecommendations();
    }
}

// generate recommendations based on stress & tasks
function generateRecommendations() {
    const recommendations = [];
    const recentStress = state.stressLevels.slice(-3);
    const averageStress = recentStress.reduce((acc, curr) => acc + curr.value, 0) / recentStress.length || 0;
    const now = new Date();
    
    // Stress-based recommendations
    if (averageStress > 7) {
        recommendations.push({
            type: 'warning',
            message: 'Your stress levels are high. Consider using the Focus Mode with a 25-minute Pomodoro session followed by a 5-minute break.'
        });
        recommendations.push({
            type: 'warning',
            message: 'Try some deep breathing exercises: Inhale for 4 seconds, hold for 4 seconds, exhale for 6 seconds.'
        });
    } else if (averageStress > 5) {
        recommendations.push({
            type: 'info',
            message: 'Your stress is moderate. Consider taking short breaks between tasks and stay hydrated.'
        });
    } else if (recentStress.length > 0) {
        recommendations.push({
            type: 'success',
            message: 'Your stress levels are manageable. Great job maintaining balance!'
        });
    }

    // Task-based recommendations
    const upcomingTasks = state.tasks
        .filter(task => !task.completed && new Date(task.deadline) > now)
        .sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
    
    const urgentTasks = upcomingTasks.filter(task => {
        const deadline = new Date(task.deadline);
        const hoursRemaining = (deadline - now) / (1000 * 60 * 60);
        return hoursRemaining < 24;
    });
    
    const highPriorityTasks = upcomingTasks.filter(task => task.priority === 'high');
    
    if (urgentTasks.length > 0) {
        recommendations.push({
            type: 'danger',
            message: `URGENT: You have ${urgentTasks.length} task${urgentTasks.length > 1 ? 's' : ''} due within 24 hours. Focus on "${urgentTasks[0].name}" first.`
        });
    } else if (highPriorityTasks.length > 0) {
        recommendations.push({
            type: 'warning',
            message: `You have ${highPriorityTasks.length} high-priority task${highPriorityTasks.length > 1 ? 's' : ''}. Consider working on "${highPriorityTasks[0].name}" today.`
        });
    } else if (upcomingTasks.length > 0) {
        recommendations.push({
            type: 'info',
            message: `You have ${upcomingTasks.length} upcoming task${upcomingTasks.length > 1 ? 's' : ''}. Consider prioritizing "${upcomingTasks[0].name}".`
        });
    }
    
    // Time of day recommendations
    const hour = now.getHours();
    if (hour < 12 && hour >= 5) {
        recommendations.push({
            type: 'info',
            message: 'Morning is a great time for deep work. Consider tackling your most challenging tasks now.'
        });
    } else if (hour >= 12 && hour < 15) {
        recommendations.push({
            type: 'info',
            message: 'After lunch, your energy might dip. Consider scheduling lighter tasks or a short power nap.'
        });
    } else if (hour >= 15 && hour < 19) {
        recommendations.push({
            type: 'info',
            message: 'Late afternoon is good for collaborative work and meetings before wrapping up your day.'
        });
    } else if (hour >= 19 || hour < 5) {
        recommendations.push({
            type: 'warning',
            message: 'Working late? Make sure to take breaks and avoid screen time at least 1 hour before bed.'
        });
    }

    const recommendationsHtml = recommendations
        .map(rec => `
            <div class="recommendation-item" data-type="${rec.type}">
                ${rec.message}
            </div>
        `)
        .join('');

    return recommendationsHtml;
}

// set up the analytics page
function initializeAnalytics() {
    initializeCompletionChart();
    initializeStressWorkloadChart();
}

// set up the task completion donut chart
function initializeCompletionChart() {
    const ctx = document.getElementById('completionChart').getContext('2d');
    const completedTasks = state.tasks.filter(task => task.completed).length;
    const totalTasks = state.tasks.length;
    const completionRate = totalTasks ? (completedTasks / totalTasks * 100).toFixed(1) : 0;

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Completed', 'Pending'],
            datasets: [{
                data: [completedTasks, totalTasks - completedTasks],
                backgroundColor: [
                    'rgba(52, 199, 89, 0.8)',
                    'rgba(142, 142, 147, 0.2)'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: `Completion Rate: ${completionRate}%`
                }
            }
        }
    });
}

// set up the stress vs workload line chart
function initializeStressWorkloadChart() {
    const ctx = document.getElementById('stressWorkloadChart').getContext('2d');
    const dates = [...new Set(state.stressLevels.map(sl => 
        new Date(sl.timestamp).toLocaleDateString()
    ))];
    
    const stressData = dates.map(date => {
        const dayStress = state.stressLevels
            .filter(sl => new Date(sl.timestamp).toLocaleDateString() === date)
            .map(sl => sl.value);
        return dayStress.reduce((a, b) => a + b, 0) / dayStress.length;
    });
    
    const taskData = dates.map(date => {
        return state.tasks.filter(task => 
            new Date(task.deadline).toLocaleDateString() === date
        ).length;
    });

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [
                {
                    label: 'Average Stress',
                    data: stressData,
                    borderColor: '#FF3B30',
                    yAxisID: 'y-stress'
                },
                {
                    label: 'Task Count',
                    data: taskData,
                    borderColor: '#007AFF',
                    yAxisID: 'y-tasks'
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                'y-stress': {
                    type: 'linear',
                    position: 'left',
                    min: 0,
                    max: 10,
                    title: {
                        display: true,
                        text: 'Stress Level'
                    }
                },
                'y-tasks': {
                    type: 'linear',
                    position: 'right',
                    min: 0,
                    title: {
                        display: true,
                        text: 'Number of Tasks'
                    }
                }
            }
        }
    });
}

// shows a temporary notification message
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// generic ui update function (maybe needed later?)
function updateUI() {
    updateTaskLists();
    generateRecommendations();
}

// calendar stuff
let currentDate = new Date();

function initializeCalendar() {
    // Set current date to today
    currentDate = new Date();
    
    updateCalendarMonth();
    renderCalendar();
    
    // wire up prev/next month buttons
    document.getElementById('prevMonth').addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        updateCalendarMonth();
        renderCalendar();
    });
    
    document.getElementById('nextMonth').addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        updateCalendarMonth();
        renderCalendar();
    });
}

// update the month/year title above calendar
function updateCalendarMonth() {
    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"];
    document.getElementById('currentMonth').textContent = 
        `${monthNames[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
}

// Update time and date display
function updateTimeAndDate() {
    const now = new Date();
    const timeElements = document.querySelectorAll('#currentTime');
    const dateElements = document.querySelectorAll('#currentDate');
    
    // Format time as regular time with AM/PM
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    
    const timeString = `${hours}:${minutes}:${seconds} ${ampm}`;
    
    // Format date as Day, Month Date, Year
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const dateString = `${days[now.getDay()]}, ${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    
    // Update all time and date elements on the page
    timeElements.forEach(el => {
        if (el) el.textContent = timeString;
    });
    
    dateElements.forEach(el => {
        if (el) el.textContent = dateString;
    });
}

// draw the calendar grid
function renderCalendar() {
    const calendarGrid = document.getElementById('calendarGrid');
    if (!calendarGrid) return;
    
    calendarGrid.innerHTML = '';
    
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    
    const firstDayToShow = new Date(firstDay);
    firstDayToShow.setDate(firstDayToShow.getDate() - firstDay.getDay());
    
    const tasks = state.tasks || [];
    
    for (let i = 0; i < 42; i++) {
        const currentDayToShow = new Date(firstDayToShow);
        currentDayToShow.setDate(firstDayToShow.getDate() + i);
        
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day';
        
        if (currentDayToShow.getMonth() !== currentDate.getMonth()) {
            dayElement.classList.add('other-month');
        }
        
        if (isToday(currentDayToShow)) {
            dayElement.classList.add('today');
        }
        
        const dateNumber = document.createElement('div');
        dateNumber.className = 'date-number';
        dateNumber.textContent = currentDayToShow.getDate();
        dayElement.appendChild(dateNumber);
        
        // container for tasks within the day
        const tasksContainer = document.createElement('div');
        tasksContainer.className = 'tasks-container';
        
        const dayTasks = tasks.filter(task => {
            const taskDate = new Date(task.deadline);
            return taskDate.toDateString() === currentDayToShow.toDateString();
        });
        
        // add task previews (max 2)
        dayTasks.slice(0, 2).forEach(task => {
            const taskPreview = document.createElement('div');
            taskPreview.className = `task-preview ${(task.priority || 'medium').toLowerCase()}`;
            taskPreview.textContent = task.name;
            tasksContainer.appendChild(taskPreview);
        });
        
        // add priority dots if > 2 tasks (max 5 dots)
        if (dayTasks.length > 2) {
            const dotContainer = document.createElement('div');
            dotContainer.className = 'dots-container'; // use the css class
            
            dayTasks.slice(2, 7).forEach(task => {
                const dot = document.createElement('div');
                dot.className = `task-dot ${(task.priority || 'medium').toLowerCase()}`;
                dotContainer.appendChild(dot);
            });
            
            tasksContainer.appendChild(dotContainer);
        }
        
        dayElement.appendChild(tasksContainer); // add tasks container to day cell
        calendarGrid.appendChild(dayElement);
    }
    
    updateTimeBlocks();
}

// checks if a date is today
function isToday(date) {
    const today = new Date();
    return date.toDateString() === today.toDateString();
}

// update the time blocks list for today
function updateTimeBlocks() {
    const timeBlocksContainer = document.getElementById('timeBlocks');
    if (!timeBlocksContainer) return;
    
    const today = new Date();
    const tasks = state.tasks || [];
    
    // get today's tasks
    const todayTasks = tasks.filter(task => {
        const taskDate = new Date(task.deadline);
        return taskDate.toDateString() === today.toDateString();
    });
    
    // sort by time
    todayTasks.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
    
    // update the html
    timeBlocksContainer.innerHTML = todayTasks.length ? 
        todayTasks.map(task => `
            <div class="time-block" data-priority="${task.priority || 'Medium'}">
                <div class="time-block-time">${formatTime(new Date(task.deadline))}</div>
                <div class="time-block-name">${task.name}</div>
                <div class="time-block-priority ${task.priority || 'Medium'}">${task.priority || 'Medium'}</div>
            </div>
        `).join('') :
        '<p class="empty-state">No tasks scheduled for today</p>';
}

// format date obj to just time string (e.g., 02:30 PM)
function formatTime(date) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Calculate stress level based on all assignments
function calculateTaskStress() {
    const now = new Date();
    let stressScore = 0;
    let taskCount = 0;
    
    // Priority weights - how much each priority level contributes to stress
    const priorityWeights = {
        'low': 1,
        'medium': 2.5,
        'high': 5  // Increased from 5 to 7.5 to make high priority tasks more stressful
    };
    
    // Time factor weights - how much the deadline proximity affects stress
    const getTimeFactorWeight = (daysUntilDue) => {
        if (daysUntilDue < 0) return 2.0;  // Overdue tasks create high stress
        if (daysUntilDue === 0) return 1.8; // Due today
        if (daysUntilDue === 1) return 1.5; // Due tomorrow
        if (daysUntilDue <= 3) return 1.2; // Due in 2-3 days
        if (daysUntilDue <= 7) return 1.0; // Due this week
        if (daysUntilDue <= 14) return 0.7; // Due next week
        return 0.3; // Due in more than 2 weeks
    };
    
    // Count total tasks for density factor
    const totalTasks = state.tasks.filter(task => !task.completed).length;
    
    // Task density factor - more tasks = more stress
    const taskDensityFactor = Math.min(2, 1 + (totalTasks / 10));
    
    // Analyze each incomplete task
    state.tasks.forEach(task => {
        if (!task.completed) {
            taskCount++;
            
            // Get deadline and calculate days until due
            const deadline = new Date(task.deadline);
            const daysUntilDue = Math.ceil((deadline - now) / (1000 * 60 * 60 * 24));
            
            // Get priority weight (default to medium if not specified)
            const priority = (task.priority || 'medium').toLowerCase();
            const priorityWeight = priorityWeights[priority] || priorityWeights.medium;
            
            // Get time factor weight based on how soon the task is due
            const timeFactorWeight = getTimeFactorWeight(daysUntilDue);
            
            // Calculate individual task stress and add to total
            const taskStress = priorityWeight * timeFactorWeight;
            stressScore += taskStress;
            
            console.log(`Task: ${task.name}, Priority: ${priority}, Days until due: ${daysUntilDue}, Stress contribution: ${taskStress.toFixed(1)}`);
        }
    });
    
    // Apply task density factor
    stressScore *= taskDensityFactor;
    
    // Normalize to 1-10 scale
    // Base formula creates a curve that rises quickly at first then levels off
    let normalizedStress = 1 + Math.min(9, Math.round(Math.log(1 + stressScore) * 2.5));
    
    // Ensure minimum stress level is 1
    normalizedStress = Math.max(1, normalizedStress);
    
    console.log(`Total tasks: ${taskCount}, Task density factor: ${taskDensityFactor.toFixed(2)}`);
    console.log(`Raw stress score: ${stressScore.toFixed(2)}, Normalized (1-10): ${normalizedStress}`);
    
    return normalizedStress;
}

// update stress level based on tasks
function updateStressFromTasks() {
    const stressLevel = calculateTaskStress(); // Already normalized to 1-10 scale
    const stressSlider = document.getElementById('stressLevel');
    
    if (stressSlider) {
        // Use the stress level directly - it's already normalized to 1-10
        // No need to recalculate or normalize again
        
        // update slider and value display
        stressSlider.value = stressLevel;
        document.querySelector('.stress-value').textContent = `${stressLevel}/10`;
        
        // save the new stress level
        state.stressLevels.push({
            value: stressLevel,
            timestamp: new Date().toISOString()
        });
        
        saveDataToStorage();
        
        // update any charts or insights
        if (window.stressChart) updateStressChart();
        if (window.stressHistoryChart) updateStressHistoryChart();
        if (document.getElementById('stressInsights')) updateStressInsights();
        if (document.getElementById('recommendationsList')) updateRecommendations();
    }
}

// Add confetti effect function
function triggerConfetti() {
    const end = Date.now() + 3 * 1000; // 3 seconds
    const colors = ["#a786ff", "#fd8bbc", "#eca184", "#f8deb1"];

    const frame = () => {
        if (Date.now() > end) return;

        confetti({
            particleCount: 2,
            angle: 60,
            spread: 55,
            startVelocity: 60,
            origin: { x: 0, y: 0.5 },
            colors: colors,
        });
        confetti({
            particleCount: 2,
            angle: 120,
            spread: 55,
            startVelocity: 60,
            origin: { x: 1, y: 0.5 },
            colors: colors,
        });

        requestAnimationFrame(frame);
    };

    frame();
}

// Pomodoro Timer
let timerInterval;
let isPaused = false;
let timeLeft = 1500; // 25 minutes in seconds
let rippleAnimations = [];

// Variable to track if StudyBuddy is expanded
let isStudyBuddyExpanded = false;

// Function to expand StudyBuddy to full screen
function expandStudyBuddy() {
  const studyBuddyContainer = document.querySelector('#focusMode > div:nth-child(3)');
  if (!studyBuddyContainer || isStudyBuddyExpanded) return;
  
  // Save original styles before expanding
  if (!studyBuddyContainer.dataset.originalStyles) {
    studyBuddyContainer.dataset.originalStyles = JSON.stringify({
      position: studyBuddyContainer.style.position,
      right: studyBuddyContainer.style.right,
      top: studyBuddyContainer.style.top,
      transform: studyBuddyContainer.style.transform,
      width: studyBuddyContainer.style.width,
      height: studyBuddyContainer.style.height,
      zIndex: studyBuddyContainer.style.zIndex
    });
  }
  
  // Add transition for smooth expansion
  studyBuddyContainer.style.transition = 'all 0.3s ease-in-out';
  
  // Expand to full screen
  studyBuddyContainer.style.position = 'fixed';
  studyBuddyContainer.style.right = '0';
  studyBuddyContainer.style.top = '0';
  studyBuddyContainer.style.transform = 'none';
  studyBuddyContainer.style.width = '100vw';
  studyBuddyContainer.style.height = '100vh';
  studyBuddyContainer.style.zIndex = '20';
  
  // Make the chat content area larger
  const chatContent = document.getElementById('focusStudyBuddyContent');
  if (chatContent) {
    chatContent.style.transition = 'all 0.3s ease-in-out';
    chatContent.style.height = '70vh';
  }
  
  // Add escape key instruction
  const escapeInstruction = document.createElement('div');
  escapeInstruction.id = 'escapeInstruction';
  escapeInstruction.style.position = 'absolute';
  escapeInstruction.style.top = '10px';
  escapeInstruction.style.right = '10px';
  escapeInstruction.style.color = 'rgba(255, 255, 255, 0.7)';
  escapeInstruction.style.padding = '5px 10px';
  escapeInstruction.style.borderRadius = '5px';
  escapeInstruction.style.backgroundColor = 'rgba(0, 0, 0, 0.2)';
  escapeInstruction.innerHTML = 'Press <kbd>ESC</kbd> to exit full screen';
  studyBuddyContainer.appendChild(escapeInstruction);
  
  isStudyBuddyExpanded = true;
}

// Function to restore StudyBuddy to normal size
function restoreStudyBuddy() {
  const studyBuddyContainer = document.querySelector('#focusMode > div:nth-child(3)');
  if (!studyBuddyContainer || !isStudyBuddyExpanded) return;
  
  // Restore original styles
  if (studyBuddyContainer.dataset.originalStyles) {
    const originalStyles = JSON.parse(studyBuddyContainer.dataset.originalStyles);
    Object.keys(originalStyles).forEach(key => {
      studyBuddyContainer.style[key] = originalStyles[key];
    });
  }
  
  // Restore chat content area size
  const chatContent = document.getElementById('focusStudyBuddyContent');
  if (chatContent) {
    chatContent.style.height = '300px';
  }
  
  // Remove escape instruction
  const escapeInstruction = document.getElementById('escapeInstruction');
  if (escapeInstruction) {
    escapeInstruction.remove();
  }
  
  isStudyBuddyExpanded = false;
}

function startFocus() {
  // Reset timer
  timeLeft = 1500; // 25 minutes in seconds
  isPaused = false;
  
  // Clear any existing timer
  clearInterval(timerInterval);
  
  // Create a simple focus mode HTML with light blue/white styling to match user preferences
  const focusHTML = `
  <div id="focusMode" style="
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background-color: #1a1a2e;
    z-index: 9999;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  ">
    <!-- Background ripples -->
    <div id="rippleContainer" style="
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
      z-index: 1;
    "></div>
    
    <!-- Timer container -->
    <div style="
      position: relative;
      z-index: 10;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      background-color: rgba(230, 240, 255, 0.15);
      backdrop-filter: blur(10px);
      border-radius: 1rem;
      box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.4);
      margin-bottom: 2rem;
    ">
      <!-- Timer circle -->
      <div style="
        width: 300px;
        height: 300px;
        border-radius: 50%;
        background: linear-gradient(145deg, rgba(66, 133, 244, 0.2), rgba(219, 68, 55, 0.2));
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 2rem;
        border: 2px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 0 30px rgba(66, 133, 244, 0.3);
      ">
        <span id="currentTime" style="
          font-size: 5rem;
          font-weight: bold;
          color: white;
          text-shadow: 0 0 10px rgba(255, 255, 255, 0.5);
        ">25:00</span>
      </div>
      
      <!-- Timer controls -->
      <div style="
        display: flex;
        gap: 1rem;
        margin-bottom: 1.5rem;
      ">
        <button id="pausePlayButton" style="
          background-color: rgba(230, 240, 255, 0.2);
          border: 1px solid rgba(255, 255, 255, 0.3);
          color: white;
          padding: 0.75rem 1.5rem;
          border-radius: 2rem;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 1rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        "><i class="bi bi-pause-fill"></i> Pause</button>
        
        <button id="resetButton" style="
          background-color: rgba(230, 240, 255, 0.2);
          border: 1px solid rgba(255, 255, 255, 0.3);
          color: white;
          padding: 0.75rem 1.5rem;
          border-radius: 2rem;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 1rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        "><i class="bi bi-arrow-counterclockwise"></i> Reset</button>
        
        <button id="stopButton" style="
          background-color: rgba(230, 240, 255, 0.2);
          border: 1px solid rgba(255, 255, 255, 0.3);
          color: white;
          padding: 0.75rem 1.5rem;
          border-radius: 2rem;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 1rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        "><i class="bi bi-stop-fill"></i> Stop</button>
      </div>
      
      <div style="
        font-style: italic;
        color: rgba(255, 255, 255, 0.7);
        text-align: center;
      ">"Deep focus is the superpower of the 21st century."</div>
    </div>
    
    <!-- Study Buddy -->
    <div style="
      position: absolute;
      right: 30px;
      top: 50%;
      transform: translateY(-50%);
      width: 300px;
      background-color: rgba(230, 240, 255, 0.15);
      backdrop-filter: blur(10px);
      border-radius: 1rem;
      padding: 1.5rem;
      border: 1px solid rgba(255, 255, 255, 0.4);
      color: white;
      z-index: 10;
    ">
      <div style="
        font-size: 1.2rem;
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
      ">
        <i class="bi bi-robot"></i> Study Buddy
      </div>
      
      <div id="focusStudyBuddyContent" style="
        height: 300px;
        overflow-y: auto;
        margin-bottom: 1rem;
        padding-right: 0.5rem;
      ">
        <div style="
          background-color: rgba(255, 255, 255, 0.1);
          padding: 0.75rem;
          border-radius: 0.5rem;
          margin-bottom: 0.5rem;
        ">
          <p>I'm here to help during your focus session. What are you working on?</p>
        </div>
      </div>
      
      <div style="
        display: flex;
        gap: 0.5rem;
      ">
        <input type="text" id="focusChatInput" placeholder="Ask me anything..." style="
          flex: 1;
          background-color: rgba(255, 255, 255, 0.1);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 0.5rem;
          padding: 0.5rem 1rem;
          color: white;
          outline: none;
        ">
        
        <button id="focusSendChat" style="
          background-color: rgba(66, 133, 244, 0.5);
          border: none;
          border-radius: 0.5rem;
          width: 40px;
          height: 40px;
          display: flex;
          justify-content: center;
          align-items: center;
          cursor: pointer;
          transition: all 0.3s ease;
        "><i class="bi bi-send"></i></button>
      </div>
    </div>
  </div>
  `;
  
  // First, remove any existing focus overlay
  const existingOverlay = document.getElementById('focusMode');
  if (existingOverlay) {
    existingOverlay.remove();
  }
  
  // Hide the app container
  const appContainer = document.querySelector('.app-container');
  if (appContainer) {
    appContainer.style.display = 'none';
  }
  
  // Add the focus mode HTML to the body
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = focusHTML;
  document.body.appendChild(tempDiv.firstElementChild);
  
  // Create ripple effects
  createRipples();
  
  // Start the timer immediately
  updateTimerDisplay();
  
  // Clear any existing timer interval
  if (timerInterval) {
    clearInterval(timerInterval);
  }
  
  // Set up a new timer interval
  timerInterval = setInterval(function() {
    if (!isPaused) {
      timeLeft--;
      
      // Update the timer display
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      const formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
      
      const timerDisplay = document.getElementById('timerDisplay');
      if (timerDisplay) {
        timerDisplay.textContent = formattedTime;
      }
      
      // Update document title
      document.title = `${formattedTime} - Focus Mode | TimeTravel`;
      
      // Check if timer is complete
      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        
        // Play completion sound if available
        try {
          const audio = new Audio('sounds/complete.mp3');
          audio.play().catch(e => console.log('Audio play error:', e));
        } catch (e) {
          console.log('Error with audio:', e);
        }
        
        // Show completion message
        const focusStudyBuddyContent = document.getElementById('focusStudyBuddyContent');
        if (focusStudyBuddyContent) {
          const messageDiv = document.createElement('div');
          messageDiv.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
          messageDiv.style.padding = '0.75rem';
          messageDiv.style.borderRadius = '0.5rem';
          messageDiv.style.marginBottom = '0.5rem';
          messageDiv.innerHTML = `<p>Great job! You've completed a 25-minute focus session. Take a 5-minute break before starting another session.</p>`;
          focusStudyBuddyContent.appendChild(messageDiv);
          focusStudyBuddyContent.scrollTop = focusStudyBuddyContent.scrollHeight;
        }
      }
    }
  }, 1000);
  
  // Start the timer
  setTimeout(() => {
    startFocusTimer();
    console.log('Focus timer started automatically');
  }, 500);

  // Add event listeners
  document.getElementById('pausePlayButton').addEventListener('click', () => {
    isPaused = !isPaused;
    document.getElementById('pausePlayButton').innerHTML = isPaused ? 
      '<i class="bi bi-play-fill"></i> Play' : 
      '<i class="bi bi-pause-fill"></i> Pause';
  });
  
  // Add event listener for Escape key to restore StudyBuddy
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isStudyBuddyExpanded) {
      restoreStudyBuddy();
    }
  });
  
  document.getElementById('resetButton').addEventListener('click', () => {
    // Clear existing timer
    clearInterval(timerInterval);
    
    // Reset time
    timeLeft = 1500;
    
    // Reset pause state
    isPaused = false;
    document.getElementById('pausePlayButton').innerHTML = '<i class="bi bi-pause-fill"></i> Pause';
    
    // Start a new timer
    startFocusTimer();
  });
  
  document.getElementById('stopButton').addEventListener('click', stopFocus);
  
  const focusSendChat = document.getElementById('focusSendChat');
  const focusChatInput = document.getElementById('focusChatInput');
  if (focusSendChat && focusChatInput) {
    focusSendChat.addEventListener('click', sendFocusMessage);
    focusChatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') sendFocusMessage();
    });
  }
  
  // Request fullscreen
  const docEl = document.documentElement;
  if (docEl.requestFullscreen) {
    docEl.requestFullscreen().catch(err => {
      console.log('Error attempting to enable fullscreen:', err);
    });
  } else if (docEl.mozRequestFullScreen) { // Firefox
    docEl.mozRequestFullScreen();
  } else if (docEl.webkitRequestFullscreen) { // Chrome, Safari, Opera
    docEl.webkitRequestFullscreen();
  } else if (docEl.msRequestFullscreen) { // IE/Edge
    docEl.msRequestFullscreen();
  }
}

function createRipples() {
  // Find the ripple container
  const rippleContainer = document.getElementById('rippleContainer');
  if (!rippleContainer) {
    console.error('Ripple container not found');
    return;
  }
  
  // Clear any existing ripples
  rippleContainer.innerHTML = '';
  rippleAnimations = [];
  
  // Colors for the ripples
  const colors = [
    'rgba(66, 133, 244, 0.4)', // Blue
    'rgba(219, 68, 55, 0.4)',   // Red
    'rgba(244, 180, 0, 0.4)',    // Yellow
    'rgba(15, 157, 88, 0.4)',    // Green
    'rgba(98, 0, 238, 0.4)'      // Purple
  ];
  
  // Create multiple ripple elements
  for (let i = 0; i < 5; i++) {
    const ripple = document.createElement('div');
    ripple.style.position = 'absolute';
    ripple.style.top = '50%';
    ripple.style.left = '50%';
    ripple.style.transform = 'translate(-50%, -50%)';
    ripple.style.borderRadius = '50%';
    ripple.style.background = `radial-gradient(circle, ${colors[i]} 0%, ${colors[i].replace('0.4', '0')} 70%)`;
    ripple.style.width = '10px';
    ripple.style.height = '10px';
    ripple.style.pointerEvents = 'none';
    ripple.style.zIndex = '1';
    
    // Add animation
    ripple.style.animation = `rippleAnimation ${15 + i * 2}s linear infinite`;
    ripple.style.animationDelay = `${i * 3}s`;
    
    rippleContainer.appendChild(ripple);
    rippleAnimations.push(ripple);
  }
  
  // Add the keyframe animation dynamically if it doesn't exist
  if (!document.getElementById('rippleAnimationStyle')) {
    const style = document.createElement('style');
    style.id = 'rippleAnimationStyle';
    style.textContent = `
      @keyframes rippleAnimation {
        0% {
          width: 10px;
          height: 10px;
          opacity: 1;
        }
        100% {
          width: 2000px;
          height: 2000px;
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);
  }
  
  console.log('Ripple animations created:', rippleAnimations.length);
}

// New dedicated function for focus timer
function startFocusTimer() {
  console.log('Starting focus timer');
  
  // Clear any existing timer
  clearInterval(timerInterval);
  
  // Format and display the initial time
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  
  // Get the timer display element
  const timerElement = document.getElementById('currentTime');
  if (timerElement) {
    console.log('Timer element found:', timerElement);
    timerElement.textContent = formattedTime;
  } else {
    console.error('Timer element not found!');
  }
  
  // Start the countdown
  timerInterval = setInterval(() => {
    if (!isPaused && timeLeft > 0) {
      // Decrement the time
      timeLeft--;
      
      // Format the time
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      const formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
      
      // Update the display
      const timerElement = document.getElementById('currentTime');
      if (timerElement) {
        timerElement.textContent = formattedTime;
        console.log('Updated timer to:', formattedTime);
      }
      
      // Update document title
      document.title = `${formattedTime} - Focus Mode | TimeTravel`;
      
      // Check if timer is complete
      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        
        // Play completion sound
        const audio = new Audio('sounds/complete.mp3');
        audio.play().catch(e => console.log('Audio play error:', e));
        
        // Show completion message
        const focusStudyBuddyContent = document.getElementById('focusStudyBuddyContent');
        if (focusStudyBuddyContent) {
          const messageDiv = document.createElement('div');
          messageDiv.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
          messageDiv.style.padding = '0.75rem';
          messageDiv.style.borderRadius = '0.5rem';
          messageDiv.style.marginBottom = '0.5rem';
          messageDiv.innerHTML = `<p>Great job! You've completed a 25-minute focus session. Take a 5-minute break before starting another session.</p>`;
          focusStudyBuddyContent.appendChild(messageDiv);
          focusStudyBuddyContent.scrollTop = focusStudyBuddyContent.scrollHeight;
        }
      }
    }
  }, 1000);
  
  console.log('Timer interval started:', timerInterval);
}

// This function is replaced by startFocusTimer
function updateTimerDisplay() {
  // Deprecated
}

// Welcome popup function
function showWelcomePopup() {
  // Check if the user has seen the welcome popup before
  if (localStorage.getItem('welcomeShown')) {
    return; // User has seen it before, don't show again
  }
  
  // Create the welcome popup HTML
  const welcomeHTML = `
  <div id="welcomePopup" style="
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background-color: rgba(0, 0, 0, 0.7);
    z-index: 10000;
    display: flex;
    justify-content: center;
    align-items: center;
  ">
    <div style="
      width: 80%;
      max-width: 700px;
      background-color: rgba(230, 240, 255, 0.85);
      border-radius: 1rem;
      box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.4);
      padding: 2rem;
      color: #2D3748;
      position: relative;
    ">
      <h2 style="
        font-size: 1.8rem;
        margin-bottom: 1.5rem;
        color: #2D3748;
        text-align: center;
      ">Welcome to TimeTravel</h2>
      
      <p style="
        font-size: 1.1rem;
        margin-bottom: 1rem;
        line-height: 1.5;
        color: #4A5568;
      ">TimeTravel is your all-in-one productivity companion designed to help you manage your time effectively and reduce stress.</p>
      
      <h3 style="
        font-size: 1.4rem;
        margin: 1.5rem 0 1rem;
        color: #2D3748;
      ">Key Features:</h3>
      
      <ul style="
        list-style-type: none;
        padding: 0;
        margin-bottom: 1.5rem;
      ">
        <li style="
          padding: 0.5rem 0;
          display: flex;
          align-items: center;
          color: #4A5568;
        ">
          <span style="
            background-color: rgba(66, 133, 244, 0.2);
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 1rem;
          "><i class="bi bi-clock"></i></span>
          <strong>Focus Timer:</strong> Use the Pomodoro technique with our distraction-free focus mode
        </li>
        
        <li style="
          padding: 0.5rem 0;
          display: flex;
          align-items: center;
          color: #4A5568;
        ">
          <span style="
            background-color: rgba(219, 68, 55, 0.2);
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 1rem;
          "><i class="bi bi-list-check"></i></span>
          <strong>Task Management:</strong> Organize your tasks with priorities and deadlines
        </li>
        
        <li style="
          padding: 0.5rem 0;
          display: flex;
          align-items: center;
          color: #4A5568;
        ">
          <span style="
            background-color: rgba(15, 157, 88, 0.2);
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 1rem;
          "><i class="bi bi-calendar-week"></i></span>
          <strong>Weekly Planner:</strong> Plan your week with our intuitive calendar view
        </li>
        
        <li style="
          padding: 0.5rem 0;
          display: flex;
          align-items: center;
          color: #4A5568;
        ">
          <span style="
            background-color: rgba(244, 180, 0, 0.2);
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 1rem;
          "><i class="bi bi-robot"></i></span>
          <strong>StudyBuddy AI:</strong> Get personalized recommendations and assistance
        </li>
        
        <li style="
          padding: 0.5rem 0;
          display: flex;
          align-items: center;
          color: #4A5568;
        ">
          <span style="
            background-color: rgba(98, 0, 238, 0.2);
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 1rem;
          "><i class="bi bi-graph-up"></i></span>
          <strong>Stress Management:</strong> Track and manage your stress levels with adaptive recommendations
        </li>
      </ul>
      
      <p style="
        font-size: 1.1rem;
        margin-bottom: 1.5rem;
        line-height: 1.5;
        color: #4A5568;
        text-align: center;
        font-style: italic;
      ">"Time management is not about managing your time, but about managing yourself."</p>
      
      <div style="
        display: flex;
        justify-content: center;
      ">
        <button id="welcomeCloseButton" style="
          background-color: rgba(66, 133, 244, 0.9);
          color: white;
          border: none;
          border-radius: 2rem;
          padding: 0.75rem 2rem;
          font-size: 1.1rem;
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        ">Get Started</button>
      </div>
    </div>
  </div>
  `;
  
  // Add the welcome popup to the body
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = welcomeHTML;
  document.body.appendChild(tempDiv.firstElementChild);
  
  // Add event listener to close button
  document.getElementById('welcomeCloseButton').addEventListener('click', () => {
    const welcomePopup = document.getElementById('welcomePopup');
    if (welcomePopup) {
      // Add fade-out animation
      welcomePopup.style.transition = 'opacity 0.5s ease';
      welcomePopup.style.opacity = '0';
      
      // Remove after animation completes
      setTimeout(() => {
        welcomePopup.remove();
      }, 500);
      
      // Set flag in localStorage so we don't show it again
      localStorage.setItem('welcomeShown', 'true');
    }
  });
}

// Set up event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Show welcome popup
  showWelcomePopup();
  
  const startTimerButton = document.getElementById('startTimer');
  
  if (startTimerButton) {
    startTimerButton.addEventListener('click', startFocus);
  }
});

function sendFocusMessage() {
  const focusChatInput = document.getElementById('focusChatInput');
  const focusStudyBuddyContent = document.getElementById('focusStudyBuddyContent');
  
  if (!focusChatInput || !focusStudyBuddyContent) return;
  
  const message = focusChatInput.value.trim();
  if (!message) return;
  
  // Expand StudyBuddy to full screen when a question is asked
  expandStudyBuddy();
  
  // Add user message
  const userDiv = document.createElement('div');
  userDiv.style.backgroundColor = 'rgba(66, 133, 244, 0.2)';
  userDiv.style.padding = '0.75rem';
  userDiv.style.borderRadius = '0.5rem';
  userDiv.style.marginBottom = '0.5rem';
  userDiv.style.marginLeft = '1rem';
  userDiv.style.textAlign = 'right';
  userDiv.innerHTML = `<p>${message}</p>`;
  focusStudyBuddyContent.appendChild(userDiv);
  
  // Clear input
  focusChatInput.value = '';
  
  // Auto-scroll to bottom
  focusStudyBuddyContent.scrollTop = focusStudyBuddyContent.scrollHeight;
  
  // Generate AI response
  setTimeout(() => {
    const responses = [
      "Remember to stay focused on your current task. You're doing great!",
      "Need help breaking down your task into smaller steps?",
      "Try the Pomodoro technique - 25 minutes of focus, then a 5-minute break.",
      "Deep breathing can help maintain focus. Try breathing in for 4 seconds, hold for 4, out for 6.",
      "What specific part are you working on right now?",
      "Remember to stay hydrated during your focus session.",
      "If you're feeling stuck, try explaining the problem out loud.",
      "You've got this! Keep going!",
      "Would you like me to help you brainstorm solutions?",
      "Focus on progress, not perfection."
    ];
    
    const response = responses[Math.floor(Math.random() * responses.length)];
    
    const botDiv = document.createElement('div');
    botDiv.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
    botDiv.style.padding = '0.75rem';
    botDiv.style.borderRadius = '0.5rem';
    botDiv.style.marginBottom = '0.5rem';
    botDiv.innerHTML = `<p>${response}</p>`;
    focusStudyBuddyContent.appendChild(botDiv);
    
    // Auto-scroll to bottom again
    focusStudyBuddyContent.scrollTop = focusStudyBuddyContent.scrollHeight;
  }, 1000);
}

function setupFocusModeEventListeners() {
  const pausePlayButton = document.getElementById('pausePlayButton');
  const resetButton = document.getElementById('resetButton');
  const stopButton = document.getElementById('stopButton');
  const focusSendChat = document.getElementById('focusSendChat');
  const focusChatInput = document.getElementById('focusChatInput');
  
  if (pausePlayButton) {
    pausePlayButton.addEventListener('click', () => {
      isPaused = !isPaused;
      pausePlayButton.innerHTML = isPaused ? 
        '<i class="bi bi-play-fill"></i> Play' : 
        '<i class="bi bi-pause-fill"></i> Pause';
    });
  }
  
  if (resetButton) {
    resetButton.addEventListener('click', () => {
      clearInterval(timerInterval);
      timeLeft = 1500;
      updateTimerDisplay();
      startTimer();
      isPaused = false;
      if (pausePlayButton) {
        pausePlayButton.innerHTML = '<i class="bi bi-pause-fill"></i> Pause';
      }
    });
  }
  
  if (stopButton) {
    stopButton.addEventListener('click', stopFocus);
  }
  
  // Study Buddy chat in focus mode
  if (focusSendChat && focusChatInput) {
    focusSendChat.addEventListener('click', () => sendFocusMessage());
    focusChatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') sendFocusMessage();
    });
  }
}

function stopFocus() {
  // Stop the timer
  clearInterval(timerInterval);
  
  // Exit fullscreen if we're in it
  if (document.exitFullscreen) {
    document.exitFullscreen().catch(err => {
      console.log('Error attempting to exit fullscreen:', err);
    });
  } else if (document.mozCancelFullScreen) { // Firefox
    document.mozCancelFullScreen();
  } else if (document.webkitExitFullscreen) { // Chrome, Safari, Opera
    document.webkitExitFullscreen();
  } else if (document.msExitFullscreen) { // IE/Edge
    document.msExitFullscreen();
  }
  
  // Remove the focus mode overlay
  const focusMode = document.getElementById('focusMode');
  if (focusMode) {
    focusMode.remove();
  }
  
  // Show the main app container again
  const appContainer = document.querySelector('.app-container');
  if (appContainer) {
    appContainer.style.display = 'flex';
  }
  
  // Clear ripple animations array
  rippleAnimations = [];
  
  // Remove the ripple animation style if it exists
  const rippleStyle = document.getElementById('rippleAnimationStyle');
  if (rippleStyle) {
    rippleStyle.remove();
  }
  
  // Reset document title
  document.title = 'TimeTravel';
}

// AI Chatbot (StudyBuddy)
const apiKey = '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';

async function sendMessageToChatbot(message) {
    try {
        const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: "llama-3.3-70b-versatile",
                messages: [{ role: "user", content: message }]
            })
        });
        const data = await response.json();
        console.log('API Response:', data); // Log the response for debugging
        if (response.ok && data.choices && data.choices[0].message) {
            return data.choices[0].message.content;
        } else {
            console.error('Error in response:', data);
            return 'Sorry, I couldn\'t understand that. Can you try asking in a different way?';
        }
    } catch (error) {
        console.error('Error communicating with chatbot:', error);
        return 'There was an error connecting to the chatbot. Please try again later.';
    }
}

// Variable to track if dashboard StudyBuddy is expanded
let isDashboardStudyBuddyExpanded = false;

// Function to expand dashboard StudyBuddy to full screen
function expandDashboardStudyBuddy() {
    if (isDashboardStudyBuddyExpanded) return;
    
    const chatbotContainer = document.getElementById('chatbot');
    const chatbotCard = chatbotContainer.closest('.bento-card');
    
    if (!chatbotContainer || !chatbotCard) return;
    
    // Save original styles and position
    if (!chatbotCard.dataset.originalStyles) {
        const rect = chatbotCard.getBoundingClientRect();
        chatbotCard.dataset.originalStyles = JSON.stringify({
            position: chatbotCard.style.position,
            top: chatbotCard.style.top,
            left: chatbotCard.style.left,
            width: chatbotCard.style.width,
            height: chatbotCard.style.height,
            zIndex: chatbotCard.style.zIndex,
            transform: chatbotCard.style.transform,
            borderRadius: chatbotCard.style.borderRadius,
            originalRect: {
                top: rect.top,
                left: rect.left,
                width: rect.width,
                height: rect.height
            }
        });
    }
    
    // Add transition for smooth expansion
    chatbotCard.style.transition = 'all 0.3s ease-in-out';
    
    // Expand to full screen
    chatbotCard.style.position = 'fixed';
    chatbotCard.style.top = '0';
    chatbotCard.style.left = '0';
    chatbotCard.style.width = '100vw';
    chatbotCard.style.height = '100vh';
    chatbotCard.style.zIndex = '1000';
    chatbotCard.style.borderRadius = '0';
    chatbotCard.style.transform = 'none';
    chatbotCard.style.overflow = 'hidden';
    
    // Make the chat window larger
    const chatWindow = document.getElementById('chatWindow');
    if (chatWindow) {
        chatWindow.style.transition = 'all 0.3s ease-in-out';
        chatWindow.style.maxHeight = '70vh';
    }
    
    // Add escape key instruction
    const escapeInstruction = document.createElement('div');
    escapeInstruction.id = 'escapeInstruction';
    escapeInstruction.style.position = 'absolute';
    escapeInstruction.style.top = '10px';
    escapeInstruction.style.right = '10px';
    escapeInstruction.style.color = 'rgba(255, 255, 255, 0.7)';
    escapeInstruction.style.padding = '5px 10px';
    escapeInstruction.style.borderRadius = '5px';
    escapeInstruction.style.backgroundColor = 'rgba(0, 0, 0, 0.2)';
    escapeInstruction.style.fontSize = '0.8rem';
    escapeInstruction.innerHTML = 'Press <kbd>ESC</kbd> to exit full screen';
    chatbotCard.appendChild(escapeInstruction);
    
    isDashboardStudyBuddyExpanded = true;
}

// Function to restore dashboard StudyBuddy to normal size
function restoreDashboardStudyBuddy() {
    if (!isDashboardStudyBuddyExpanded) return;
    
    const chatbotContainer = document.getElementById('chatbot');
    const chatbotCard = chatbotContainer.closest('.bento-card');
    
    if (!chatbotContainer || !chatbotCard) return;
    
    // Restore original styles
    if (chatbotCard.dataset.originalStyles) {
        const originalStyles = JSON.parse(chatbotCard.dataset.originalStyles);
        Object.keys(originalStyles).forEach(key => {
            if (key !== 'originalRect') {
                chatbotCard.style[key] = originalStyles[key];
            }
        });
    }
    
    // Restore chat window size
    const chatWindow = document.getElementById('chatWindow');
    if (chatWindow) {
        chatWindow.style.maxHeight = '200px';
    }
    
    // Remove escape instruction
    const escapeInstruction = document.getElementById('escapeInstruction');
    if (escapeInstruction) {
        escapeInstruction.remove();
    }
    
    isDashboardStudyBuddyExpanded = false;
}

// Add event listener for Escape key to restore StudyBuddy
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isDashboardStudyBuddyExpanded) {
        restoreDashboardStudyBuddy();
    }
});

async function handleSendChat() {
    const chatInput = document.getElementById('chatInput');
    const chatWindow = document.getElementById('chatWindow');
    const userMessage = chatInput.value.trim();
    if (!userMessage) return;
    
    // Expand StudyBuddy to full screen when a question is asked
    expandDashboardStudyBuddy();

    // Display user message
    const userMessageElement = document.createElement('div');
    userMessageElement.textContent = `You: ${userMessage}`;
    chatWindow.appendChild(userMessageElement);

    // Get and display chatbot reply
    const reply = await sendMessageToChatbot(userMessage);
    const botMessageElement = document.createElement('div');
    botMessageElement.textContent = `StudyBuddy: ${reply}`;
    chatWindow.appendChild(botMessageElement);

    chatInput.value = '';
    chatWindow.scrollTop = chatWindow.scrollHeight; // Scroll to bottom
}

document.getElementById('sendChat').addEventListener('click', handleSendChat);

const startFocusButton = document.getElementById('startFocusButton');

startFocusButton.addEventListener('click', () => {
  isPaused = false;
  startTimer();
}); 