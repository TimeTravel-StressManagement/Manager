// AI Planner functionality using Groq API
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the AI Planner
    initializePlanner();
    
    // Update time and date
    updateTimeAndDate();
    setInterval(updateTimeAndDate, 1000);
});

// Initialize the AI Planner
function initializePlanner() {
    const generatePlanBtn = document.getElementById('generatePlanBtn');
    const copyPlanBtn = document.getElementById('copyPlanBtn');
    const addToScheduleBtn = document.getElementById('addToScheduleBtn');
    const voiceInputBtn = document.getElementById('voiceInputBtn');
    
    if (generatePlanBtn) {
        generatePlanBtn.addEventListener('click', generatePlan);
    }
    
    if (copyPlanBtn) {
        copyPlanBtn.addEventListener('click', copyPlanToClipboard);
    }
    
    if (addToScheduleBtn) {
        addToScheduleBtn.addEventListener('click', addPlanToSchedule);
    }
    
    if (voiceInputBtn) {
        voiceInputBtn.addEventListener('click', toggleVoiceInput);
    }
    
    // Check if browser supports speech recognition
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        if (voiceInputBtn) {
            voiceInputBtn.style.display = 'none';
            document.getElementById('voiceStatus').textContent = 'Voice input not supported in this browser';
        }
    }
}

// Generate a plan using the Groq API
async function generatePlan() {
    const userInput = document.getElementById('userTasksInput').value.trim();
    
    if (!userInput) {
        showNotification('Please enter your tasks first.', 'warning');
        return;
    }
    
    // Show loading indicator
    document.getElementById('loadingIndicator').classList.remove('hidden');
    document.getElementById('aiPlanResult').classList.add('hidden');
    
    try {
        const apiKey = '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';
        const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'llama3-70b-8192',
                messages: [
                    {
                        role: 'system',
                        content: `You are an AI task planner that helps users organize their tasks in the most optimal and least stressful way. 
                        Your goal is to create a balanced schedule that minimizes stress while ensuring all tasks are completed on time.
                        
                        IMPORTANT FORMATTING INSTRUCTIONS:
                        1. Format EACH task entry EXACTLY as follows:
                           MM/DD/YYYY HH:MM - [PRIORITY] Task Name: Description
                        
                        2. Use 24-hour time format (e.g., 14:30 not 2:30 PM)
                        
                        3. PRIORITY must be one of: [HIGH], [MEDIUM], or [LOW]
                        
                        4. Example of correct format:
                           04/15/2025 14:30 - [HIGH] Complete Math Assignment: Calculus problems 1-10
                           04/16/2025 09:00 - [MEDIUM] Team Meeting: Weekly project update
                           04/17/2025 16:00 - [LOW] Organize Notes: Review and organize class notes
                        
                        5. Do NOT include any explanations, introductions, or conclusions
                        
                        6. Do NOT ask follow-up questions
                        
                        7. Keep your response focused ONLY on the schedule with the exact format specified
                        
                        8. Analyze the user's tasks and create a balanced schedule that minimizes stress
                        
                        9. Prioritize reducing stress by spacing out difficult tasks
                        
                        10. Consider task dependencies and deadlines when creating the schedule`
                    },
                    {
                        role: 'user',
                        content: userInput
                    }
                ],
                temperature: 0.3,
                max_tokens: 1024
            })
        });
        
        const data = await response.json();
        
        if (data.choices && data.choices[0] && data.choices[0].message) {
            const planContent = data.choices[0].message.content;
            document.getElementById('planContent').textContent = planContent;
            document.getElementById('aiPlanResult').classList.remove('hidden');
            
            // Store the plan in local storage for later use
            localStorage.setItem('timetravel_ai_plan', planContent);
        } else {
            throw new Error('Invalid response from AI service');
        }
    } catch (error) {
        console.error('Error generating plan:', error);
        showNotification('Error generating plan. Please try again.', 'error');
    } finally {
        // Hide loading indicator
        document.getElementById('loadingIndicator').classList.add('hidden');
    }
}

// Copy the generated plan to clipboard
function copyPlanToClipboard() {
    const planContent = document.getElementById('planContent').textContent;
    
    if (!planContent) {
        showNotification('No plan to copy.', 'warning');
        return;
    }
    
    navigator.clipboard.writeText(planContent)
        .then(() => {
            showNotification('Plan copied to clipboard!', 'success');
        })
        .catch(err => {
            console.error('Error copying to clipboard:', err);
            showNotification('Failed to copy plan.', 'error');
        });
}

// Add the generated plan to the schedule
function addPlanToSchedule() {
    const planContent = document.getElementById('planContent').textContent;
    
    if (!planContent) {
        showNotification('No plan to add to schedule.', 'warning');
        return;
    }
    
    // Show loading notification
    showNotification('Processing your plan...', 'info');
    
    // Parse the plan content to extract tasks
    const tasks = parsePlanToTasks(planContent);
    
    if (tasks.length === 0) {
        // Show detailed error message
        showNotification('Could not parse any tasks from the plan. Please ensure the AI output follows the correct format.', 'error');
        
        // Add a help message to the plan content
        const planContentEl = document.getElementById('planContent');
        if (planContentEl) {
            // Create a help message element
            const helpMessage = document.createElement('div');
            helpMessage.style.marginTop = '1rem';
            helpMessage.style.padding = '0.75rem';
            helpMessage.style.backgroundColor = 'rgba(219, 68, 55, 0.1)';
            helpMessage.style.borderRadius = '0.5rem';
            helpMessage.style.fontSize = '0.9rem';
            helpMessage.innerHTML = `<p><strong>Formatting Issue:</strong> The AI response doesn't follow the expected format. Try regenerating the plan or ensure each task follows this format:</p>
            <p style="font-family: monospace; margin-top: 0.5rem;">MM/DD/YYYY HH:MM - [PRIORITY] Task Name: Description</p>`;
            
            // Insert it after the plan content
            planContentEl.parentNode.insertBefore(helpMessage, planContentEl.nextSibling);
        }
        return;
    }
    
    // Add tasks to the state
    tasks.forEach(task => {
        addTaskToState(task);
    });
    
    // Save to storage
    saveDataToStorage();
    
    // Show success message with task details
    const successMessage = `
        <div style="text-align: left;">
            <p><strong>Successfully added ${tasks.length} tasks to your schedule!</strong></p>
            <ul style="margin-top: 0.5rem; padding-left: 1.5rem;">
                ${tasks.slice(0, 3).map(task => {
                    const date = new Date(task.deadline);
                    return `<li>${task.name} - ${date.toLocaleDateString()} at ${date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</li>`;
                }).join('')}
                ${tasks.length > 3 ? `<li>...and ${tasks.length - 3} more</li>` : ''}
            </ul>
        </div>
    `;
    
    // Use custom notification for rich content
    const notification = document.createElement('div');
    notification.className = `notification success`;
    notification.innerHTML = successMessage;
    document.body.appendChild(notification);
    
    // Remove after 5 seconds (longer time for user to read details)
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 5000);
    
    // Redirect to schedule page after a short delay
    setTimeout(() => {
        window.location.href = 'schedule.html';
    }, 3000);
}

// Parse the plan content to extract tasks
function parsePlanToTasks(planContent) {
    const tasks = [];
    const lines = planContent.split('\n');
    
    // Format: MM/DD/YYYY HH:MM - [PRIORITY] Task Name: Description
    const taskRegex = /(\d{1,2}\/\d{1,2}\/\d{4})\s+(\d{1,2}:\d{2})\s+-\s+\[(HIGH|MEDIUM|LOW)\]\s+([^:]+)(?::\s+(.+))?/i;
    
    console.log('Parsing plan content:', planContent);
    
    lines.forEach((line, index) => {
        line = line.trim();
        if (!line) return;
        
        console.log(`Parsing line ${index + 1}:`, line);
        
        // Try to match the standardized format
        const match = line.match(taskRegex);
        
        if (match) {
            console.log('Match found:', match);
            
            const dateStr = match[1]; // MM/DD/YYYY
            const timeStr = match[2]; // HH:MM
            const priorityStr = match[3].toLowerCase(); // HIGH, MEDIUM, or LOW
            const taskName = match[4].trim(); // Task Name
            const description = match[5] ? match[5].trim() : 'Added from AI Planner'; // Description (optional)
            
            // Parse the date and time
            try {
                // Parse MM/DD/YYYY format
                const [month, day, year] = dateStr.split('/');
                // Parse HH:MM format (24-hour)
                const [hours, minutes] = timeStr.split(':').map(num => parseInt(num, 10));
                
                // Create date object
                const dateTime = new Date(parseInt(year, 10), parseInt(month, 10) - 1, parseInt(day, 10), hours, minutes);
                
                // Validate the date
                if (!isNaN(dateTime.getTime())) {
                    tasks.push({
                        id: Date.now() + Math.floor(Math.random() * 1000) + index,
                        name: taskName,
                        description: description,
                        deadline: dateTime.toISOString(),
                        priority: priorityStr,
                        completed: false,
                        createdAt: new Date().toISOString()
                    });
                    
                    console.log('Task added:', taskName, 'with priority:', priorityStr, 'and deadline:', dateTime.toISOString());
                } else {
                    console.error('Invalid date created:', dateTime);
                }
            } catch (e) {
                console.error('Error parsing date/time:', e);
            }
        } else {
            // Fallback for non-standard format
            console.log('No match for standard format, trying fallback parsing');
            
            // Try to extract date and time with a more lenient regex
            const fallbackRegex = /(\d{1,2}\/\d{1,2}\/\d{4}|\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})\s*-?\s*(.*)/i;
            const fallbackMatch = line.match(fallbackRegex);
            
            if (fallbackMatch) {
                console.log('Fallback match found:', fallbackMatch);
                
                const dateStr = fallbackMatch[1];
                const timeStr = fallbackMatch[2];
                let taskText = fallbackMatch[3].trim();
                
                // Default values
                let priority = 'medium';
                let taskName = taskText;
                let description = 'Added from AI Planner';
                
                // Try to extract priority if in brackets
                const priorityMatch = taskText.match(/\[(high|medium|low)\]/i);
                if (priorityMatch) {
                    priority = priorityMatch[1].toLowerCase();
                    taskText = taskText.replace(priorityMatch[0], '').trim();
                }
                
                // Try to extract description if there's a colon
                const descriptionMatch = taskText.match(/([^:]+):\s+(.+)/i);
                if (descriptionMatch) {
                    taskName = descriptionMatch[1].trim();
                    description = descriptionMatch[2].trim();
                }
                
                try {
                    let dateTime;
                    
                    // Parse date based on format
                    if (dateStr.includes('/')) { // MM/DD/YYYY
                        const [month, day, year] = dateStr.split('/');
                        const [hours, minutes] = timeStr.split(':').map(num => parseInt(num, 10));
                        dateTime = new Date(parseInt(year, 10), parseInt(month, 10) - 1, parseInt(day, 10), hours, minutes);
                    } else if (dateStr.includes('-')) { // YYYY-MM-DD
                        const [year, month, day] = dateStr.split('-');
                        const [hours, minutes] = timeStr.split(':').map(num => parseInt(num, 10));
                        dateTime = new Date(parseInt(year, 10), parseInt(month, 10) - 1, parseInt(day, 10), hours, minutes);
                    }
                    
                    if (!isNaN(dateTime.getTime())) {
                        tasks.push({
                            id: Date.now() + Math.floor(Math.random() * 1000) + index,
                            name: taskName,
                            description: description,
                            deadline: dateTime.toISOString(),
                            priority: priority,
                            completed: false,
                            createdAt: new Date().toISOString()
                        });
                        
                        console.log('Task added (fallback):', taskName, 'with priority:', priority);
                    }
                } catch (e) {
                    console.error('Error in fallback parsing:', e);
                }
            } else {
                console.log('Could not parse line:', line);
            }
        }
    });
    
    console.log('Total parsed tasks:', tasks.length);
    return tasks;
}

// Add a task to the state
function addTaskToState(task) {
    if (!state.tasks) {
        state.tasks = [];
    }
    
    state.tasks.push(task);
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Voice recognition variables
let recognition;
let isListening = false;

// Initialize and toggle voice recognition
function toggleVoiceInput() {
    const voiceInputBtn = document.getElementById('voiceInputBtn');
    const voiceStatus = document.getElementById('voiceStatus');
    const userTasksInput = document.getElementById('userTasksInput');
    
    // Initialize speech recognition if not already done
    if (!recognition) {
        // Use the appropriate Speech Recognition API based on browser support
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        
        // Configure recognition settings
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';
        
        // Handle recognition results
        recognition.onresult = function(event) {
            const transcript = Array.from(event.results)
                .map(result => result[0])
                .map(result => result.transcript)
                .join('');
            
            // Update the textarea with the recognized speech
            userTasksInput.value = transcript;
            
            // Update status to show what was recognized
            if (event.results[0].isFinal) {
                voiceStatus.textContent = 'Recognized: ' + transcript;
            }
        };
        
        // Handle recognition end
        recognition.onend = function() {
            isListening = false;
            voiceInputBtn.classList.remove('listening');
            voiceStatus.textContent = 'Voice recognition stopped';
        };
        
        // Handle recognition errors
        recognition.onerror = function(event) {
            voiceStatus.textContent = 'Error: ' + event.error;
            isListening = false;
            voiceInputBtn.classList.remove('listening');
        };
    }
    
    // Toggle listening state
    if (isListening) {
        // Stop listening
        recognition.stop();
        isListening = false;
        voiceInputBtn.classList.remove('listening');
        voiceStatus.textContent = 'Voice recognition paused';
    } else {
        // Start listening
        recognition.start();
        isListening = true;
        voiceInputBtn.classList.add('listening');
        voiceStatus.textContent = 'Listening... Speak now';
    }
}

// Update time and date display
function updateTimeAndDate() {
    const now = new Date();
    const timeElements = document.querySelectorAll('#currentTime');
    const dateElements = document.querySelectorAll('#currentDate');
    
    // Format time as regular time with AM/PM
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    
    const timeString = `${hours}:${minutes}:${seconds} ${ampm}`;
    
    // Format date as Day, Month Date, Year
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const dateString = `${days[now.getDay()]}, ${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    
    // Update all time and date elements on the page
    timeElements.forEach(el => {
        if (el) el.textContent = timeString;
    });
    
    dateElements.forEach(el => {
        if (el) el.textContent = dateString;
    });
}
